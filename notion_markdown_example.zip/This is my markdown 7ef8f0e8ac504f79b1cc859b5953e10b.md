# This is my markdown

## This is my header

This is my normal text

```ruby
def example_method
	puts "Code" 
end
```

This is some `code` 

**This is red text**

> This is something important

This is also important

- 

    This is hidden

- list

![This%20is%20my%20markdown%207ef8f0e8ac504f79b1cc859b5953e10b/pass-by-reference-vs-pass-by-value-animation.gif](This%20is%20my%20markdown%207ef8f0e8ac504f79b1cc859b5953e10b/pass-by-reference-vs-pass-by-value-animation.gif)